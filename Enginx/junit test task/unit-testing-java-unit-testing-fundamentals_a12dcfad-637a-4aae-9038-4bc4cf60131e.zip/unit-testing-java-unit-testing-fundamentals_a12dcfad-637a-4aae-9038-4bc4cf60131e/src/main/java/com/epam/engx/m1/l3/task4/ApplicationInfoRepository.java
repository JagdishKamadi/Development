package com.epam.engx.m1.l3.task4;

interface ApplicationInfoRepository {

  void save(String applicationInfo);

}
