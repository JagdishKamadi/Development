package com.epam.engx.m1.l3.task1;

class StringUtils {

  boolean startsWithIgnoreCase(String str, String prefix) {
    return str.toLowerCase().startsWith(prefix.toLowerCase());
  }

}
