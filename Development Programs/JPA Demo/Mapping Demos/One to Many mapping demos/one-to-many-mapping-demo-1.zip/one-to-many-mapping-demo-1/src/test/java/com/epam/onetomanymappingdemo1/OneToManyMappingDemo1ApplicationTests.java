package com.epam.onetomanymappingdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyMappingDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
