package com.epam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserServiceDemoWithAllTypeTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiceDemoWithAllTypeTestingApplication.class, args);
	}

}
