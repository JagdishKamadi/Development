package java8.ocp.strategy.after;

public interface SortingStrategy {
    void sort(int[] array);
}

