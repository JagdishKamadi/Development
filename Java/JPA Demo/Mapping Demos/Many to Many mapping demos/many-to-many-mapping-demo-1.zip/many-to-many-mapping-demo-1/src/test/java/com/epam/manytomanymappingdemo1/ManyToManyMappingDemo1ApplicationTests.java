package com.epam.manytomanymappingdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToManyMappingDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
